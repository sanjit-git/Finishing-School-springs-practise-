package com.cap.employee;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

abstract class Employee
{
abstract void setSalary(int salary);

abstract int getSalary();

abstract void setGrade(String grade);

abstract String getGrade();

void label() {
System.out.println(" GRADE: "+getGrade());
System.out.println(" SALARY : "+getSalary());
}
}

class Engineer extends Employee {
private int salary;
private String grade;

@Override
void setSalary(int salary) {
this.salary = salary;
}

@Override
int getSalary() {
return salary;
}

@Override
void setGrade(String grade) {
this.grade = grade;
}

@Override
String getGrade() {
return grade;
}
}

class Manager extends Employee {
private int salary;
private String grade;

@Override
void setSalary(int salary) {
this.salary = salary;
}

@Override
int getSalary() {
return salary;
}

@Override
void setGrade(String grade) {
this.grade = grade;
}

@Override
String getGrade() {
return grade;
}
}

public class EmployeeProfile {

Employee emp;

public void employeeData(String[] str) {
        for (String string : str) {
String[] split = string.split(" ");
String emplName = split[0];
String grade = split[1];
String salary = split[2];

if (emplName.equalsIgnoreCase("ENGINEER")) {
emp = new Engineer();
emp.setGrade(grade);
emp.setSalary(Integer.parseInt(salary));
emp.label();

}else if (emplName.equalsIgnoreCase("MANAGER")) {
emp = new Manager();
emp.setGrade(grade);
emp.setSalary(Integer.parseInt(salary));
emp.label();
}else {
System.out.println("No valid data");
}

}
}

public static void main(String[] args) throws NumberFormatException, IOException 
{

	System.out.println("Enter number of input : ");
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	int n = Integer.parseInt(br.readLine());
	int i=0;
	
	System.out.println("Enter level of Employee ");
	String[] s=new String[n];
	while (i < n ) {
		
		String s1 = br.readLine(); // Input the number seperated by space
		s[i]=s1;
		i++;
	}
	
	
EmployeeProfile test1=new EmployeeProfile();
	test1.employeeData(s);

}
}
