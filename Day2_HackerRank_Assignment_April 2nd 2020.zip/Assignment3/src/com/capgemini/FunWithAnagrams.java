package com.capgemini;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class FunWithAnagrams {

	public static void main(String args[]) {
		String s[] = new String[4];
		Scanner scan = new Scanner(System.in);
		for (int i = 0; i < s.length; i++)
			s[i] = scan.nextLine();

		for (String print : s) {
			System.out.println("List contains " + print);
		}
		int lenthString = s.length;
		funWithAnagrams(s, lenthString);

	}

	private static void funWithAnagrams(String[] s, int lenthString) {
		List<String> asList = new ArrayList<String>(Arrays.asList(s));

		for (int i = 0; i < lenthString; i++)
			for (int j = i + 1; j < lenthString; j++)
				if (areAnagram(s[i], s[j])) {
					System.out.println(s[i] + " is anagram of " + s[j] + " so it is getting removed");
					if (asList.contains(s[j])) {
						asList.remove(s[j]);
					}
				}
		for (String print : asList)
			System.out.println(print);
	}

	private static boolean areAnagram(String string, String string2) {
		if (string.length() != string2.length())
			return false;
		else {
			char[] ArrayS1 = string.toLowerCase().toCharArray();
			char[] ArrayS2 = string2.toLowerCase().toCharArray();
			Arrays.sort(ArrayS1);
			Arrays.sort(ArrayS2);

			if (Arrays.equals(ArrayS1, ArrayS2)) {
				return true;
			} else {
				return false;
			}

		}
	}

}

