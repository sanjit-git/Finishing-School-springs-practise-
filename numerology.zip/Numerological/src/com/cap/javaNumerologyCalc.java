package com.cap;

import java.util.Scanner;



public class javaNumerologyCalc {

    public static void main(String[] args)
    {

        Scanner scan = new Scanner(System.in);

        int i, size, counter = 0, numer = 0, numLen, numFin = 0;

        int[] nums;

        char a;

        String input = "", numerValue = "";

         

        System.out.println("Enter the name for numerological analysis: ");

        input = scan.nextLine();

        scan.close();

        size = input.length();

        while(counter < size)

        {

            a = input.charAt(counter);

            if(a == 'a' || a == 'i' || a == 'j' || a == 'q' || a == 'y'

            || a == 'A' || a == 'I' || a == 'J' || a == 'Q' || a == 'Y')

            {

                numer += 1;

            }

            else if(a == 'b' || a == 'k' || a == 'r'

                 || a == 'B' || a == 'K' || a == 'R')

            {

                numer += 2;

            }

            else if(a == 'c' || a == 'g' || a == 'l' || a == 's'

                 || a == 'C' || a == 'G' || a == 'L' || a == 'S')

            {

                numer += 3;

            }

            else if(a == 'd' || a == 'm' || a == 't'

                 || a == 'D' || a == 'M' || a == 'T')

            {

                numer += 4;

            }

            else if(a == 'e' || a == 'h' || a == 'n' || a == 'x'

                 || a == 'E' || a == 'H' || a == 'N' || a == 'X')

            {

                numer += 5;

            }

            else if(a == 'u' || a == 'v' || a == 'w'

                 || a == 'U' || a == 'V' || a == 'W')

            {

                numer += 6;

            }

            else if(a == 'o' || a == 'z' 

                  ||a == 'O' || a == 'Z')

            {

                numer += 7;

            }

            else if(a == 'f' || a == 'p'

                 || a == 'F' || a == 'P')

            {

                numer += 8;

            }
            
            counter++;

        }

        numerValue += numer;

        numLen = numerValue.length();

        nums = new int[numLen];

        for(i = 0; i < numLen; i++)

        {

            if(numerValue.charAt(i)== '0')

                nums[i] = 0;

            else if(numerValue.charAt(i)== '1')

                nums[i] = 1;

            else if(numerValue.charAt(i)== '2')

                nums[i] = 2;

            else if(numerValue.charAt(i)== '3')

                nums[i] = 3;

            else if(numerValue.charAt(i)== '4')

                nums[i] = 4;

            else if(numerValue.charAt(i)== '5')

                nums[i] = 5;

            else if(numerValue.charAt(i)== '6')

                nums[i] = 6;

            else if(numerValue.charAt(i)== '7')

                nums[i] = 7;

            else if(numerValue.charAt(i)== '8')

                nums[i] = 8;
            
            else if(numerValue.charAt(i)== '9')

                nums[i] = 8;

        }

        for(i = 0; i < nums.length; i++)

        {
        	
                numFin += nums[i];

        }

        System.out.println("The name, '"+input+"', adds to "+numer+" and totals sum value "+ numFin+"!");

         

    }

 

}
