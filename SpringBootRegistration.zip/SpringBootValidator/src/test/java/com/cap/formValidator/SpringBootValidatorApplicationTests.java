package com.cap.formValidator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
