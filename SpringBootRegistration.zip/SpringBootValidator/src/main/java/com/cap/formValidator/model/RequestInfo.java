package com.cap.formValidator.model;


import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//import org.hibernate.validator.constraints.Email;
 
public class RequestInfo {
 
	@NotBlank(message = "Name is mandatory")
  private String name;
  
	@NotBlank(message = "job is mandatory")
  private String job;
  
  @Email
  private String email;
  
  @Size(min = 5, max = 255, message = "Please enter between {min} and {max} characters.")
  private String text;
 
  public String getEmail() {
    return email;
  }
 
  public void setEmail(String email) {
    this.email = email;
  }
 
  public String getText() {
    return text;
  }
 
  public void setText(String text) {
    this.text = text;
  }
  
  public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getJob() {
	return job;
}

public void setJob(String job) {
	this.job = job;
}

@Override
  public String toString() {
    return "RequestInfo [name="+ name + ", email=" + email + ", text=" + text + "]";
  }
 
}
