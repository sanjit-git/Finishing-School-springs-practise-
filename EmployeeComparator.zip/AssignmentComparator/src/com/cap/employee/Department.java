package com.cap.employee;

import java.util.Comparator;

public class Department 
{
int departmentId;
String departmentName;
String location;

public Department(int departmentId, String departmentName, String location) {
	super();
	this.departmentId = departmentId;
	this.departmentName = departmentName;
	this.location = location;
}


}

class LocationComparator implements Comparator<Department>{  
public int compare(Department o1,Department o2){  
	Department L1=(Department)o1;  
	Department L2=(Department)o2;  
return L1.location.compareTo(L2.location);  
}  
} 