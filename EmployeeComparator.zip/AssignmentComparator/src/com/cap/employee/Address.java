package com.cap.employee;

import java.util.Comparator;

public class Address 
{
int addressId;
String streetName;
String city;


public Address(int addressId, String streetName, String city) {
	super();
	this.addressId = addressId;
	this.streetName = streetName;
	this.city = city;
}


}

class CityComparator implements Comparator<Address>{  
public int compare(Address o1,Address o2){  
	Address c1=(Address)o1;  
	Address c2=(Address)o2;  
return c1.city.compareTo(c2.city);  
}  
} 
