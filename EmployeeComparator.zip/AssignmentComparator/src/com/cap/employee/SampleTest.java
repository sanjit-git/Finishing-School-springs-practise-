package com.cap.employee;

import java.util.ArrayList;
import java.util.*;
import java.util.Iterator;

import com.cap.employee.*;
public class SampleTest {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) 
	{
		ArrayList<Employee> al=new ArrayList<Employee>();  
		al.add(new Employee(101,"Vijay","sinha",23000,new Address(205,"Housing board","Chennai"),new Department(805,"electrical","Chennai")));  
		al.add(new Employee(106,"Ajay","reddy",27000,new Address(208,"magestic","Bangalore"),new Department(808,"computer","Bangalore")));  
		al.add(new Employee(105,"Jai","krishna",21000,new Address(206,"Andheri","Mumbai"),new Department(806,"mechanical","Mumbai"))); 
		
		
		  ArrayList<Address> ad=new ArrayList<Address>(); 
		  ad.add(new Address(205,"Housing board","Chennai"));
		  ad.add(new Address(208,"magestic","Bangalore")); 
		  ad.add(new Address(206,"Andheri","Mumbai"));
		  
		  ArrayList<Department> dp=new ArrayList<Department>(); 
		  dp.add(new Department(805,"electrical","Chennai")); 
		  dp.add(new Department(808,"computer","Bangalore")); 
		  dp.add(new Department(806,"mechanical","Mumbai"));
		 
		  System.out.println("                                   ");		
System.out.println("Sorting by Emp Id==>");  
		
		Collections.sort(al,new EmpIdComparator());  
		Iterator<Employee> itr=al.iterator();  
		while(itr.hasNext())
		{  
		Employee em=(Employee)itr.next();  
		System.out.println(em.employeeId+" "+em.firstName+" "+em.lastName+" "+em.salary);
		//+" "+em.address+" "+em.department);
		}
		
		System.out.println("                                   ");		
System.out.println("Sorting by FirstNameComparator==>");  
		
		Collections.sort(al,new FirstNameComparator());  
		Iterator<Employee> itr2=al.iterator();  
		while(itr2.hasNext())
		{  
		Employee em1=(Employee)itr2.next();  
		System.out.println(em1.employeeId+" "+em1.firstName+" "+em1.lastName+" "+em1.salary);
		//+" "+em.address+" "+em.department);
		} 
		System.out.println("                                   ");		
System.out.println("Sorting by EmpSalary==>");  
		
		Collections.sort(al,new SalaryComparator());  
		Iterator<Employee> itr4=al.iterator();  
		while(itr4.hasNext())
		{  
			Employee es=(Employee)itr4.next();  
			System.out.println(es.employeeId+" "+es.firstName+" "+es.lastName+" "+es.salary);
			//+" "+em.address+" "+em.department);
		}
		System.out.println("                                   ");		
System.out.println("Sorting by DepartmentLocation==>");  
		
			Collections.sort(dp,new LocationComparator());  
			Iterator<Department> itr3=dp.iterator();  
			while(itr3.hasNext())
			{  
			Department de=(Department)itr3.next();  
			System.out.println(de.departmentId+" "+de.departmentName+" "+de.location);  
			}
System.out.println("                                   ");
System.out.println("Sorting by Address city==>");  
			
			Collections.sort(ad,new CityComparator());  
			Iterator<Address> itr5=ad.iterator();  
			while(itr5.hasNext())
			{  
				Address a=(Address)itr5.next();  
			System.out.println(a.addressId+" "+a.streetName+" "+a.city);  
			}
		
		}
	}
