package com.cap.employee;
import java.util.*; 
public class Employee 
{
int employeeId;
String firstName;
String lastName;
int salary;
Address address;
Department department;


public Employee(int employeeId, String firstName, String lastName, int salary, Address address, Department department) {
	super();
	this.employeeId = employeeId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.salary = salary;
	this.address = address;
	this.department = department;
}


@Override
public String toString() {
	return "Employee [address=" + address + ", department=" + department + "]";
}

}
 
class EmpIdComparator implements Comparator<Employee>{  
public int compare(Employee o1,Employee o2){  
	Employee e1=(Employee)o1;  
	Employee e2=(Employee)o2;  
  
if(e1.employeeId==e2.employeeId)  
return 0;  
else if(e1.employeeId>e2.employeeId)  
return 1;  
else  
return -1;  
}  
}  


class FirstNameComparator implements Comparator<Employee>{  
public int compare(Employee o1,Employee o2){  
	Employee e1=(Employee)o1;  
	Employee e2=(Employee)o2;  
return e1.firstName.compareTo(e2.firstName);  
}  
} 

class SalaryComparator implements Comparator<Employee>{  
public int compare(Employee o1,Employee o2){  
	Employee e1=(Employee)o1;  
	Employee e2=(Employee)o2;  
	return e1.salary - e2.salary;
  
//if(e1.salary==e2.salary)  
//return 0;  
//else if(e1.salary>e2.salary)  
//return 1;  
//else  
//return -1;  
}  
}  

//class DepartmentLocationComparator implements Comparator<Object>{  
//public int compare(Object o1,Object o2){  
//	Department L1=(Department)o1;  
//	Department L2=(Department)o2;  
//return L1.location.compareTo(L2.location);  
//}  
//} 




