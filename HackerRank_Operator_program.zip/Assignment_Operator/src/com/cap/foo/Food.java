package com.cap.foo;

import java.util.*;
public class Food
{
public static void main(String args[])
{
	Scanner input  = new Scanner(System.in); 
	System.out.println("enter the meal cost=>");
	Double mealCost=input.nextDouble();
	
	System.out.println("enter the teap cost in percntage as interger value=>");
	int tipcost=input.nextInt();
	
	double tip=mealCost*tipcost/100;;
	System.out.println("tip="+tip);
	
	System.out.println("enter the tax in percntage as interger value=>");
	int taxPercent=input.nextInt();
	
	double tax=mealCost*taxPercent/100;
	System.out.println("tax="+tax);
	
	 double totalCost1=mealCost+tip+tax;
	 
	 
	
	 System.out.println("totalcost=mealCost + tip + tax =" +mealCost+" + "+tip+" + "+tax+"="+totalCost1);
	 
	int totalCost = (int)Math.round(totalCost1);
	 System.out.println("round(totalCost)="+totalCost);
	
	
}
}
