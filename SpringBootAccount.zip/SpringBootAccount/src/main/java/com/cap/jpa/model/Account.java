
package com.cap.jpa.model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@SequenceGenerator(name="seq", initialValue=1000, allocationSize=100)
@Table(name="Account")


public class Account 
{
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
@Id
//@GeneratedValue(strategy=GenerationType.SEQUENCE)
private int accountId;
private String accoutType;
@JsonFormat(pattern="dd-MM-yyyy")
private LocalDate openingDate;
private double openingBalance;
private String desc;

@ManyToOne(cascade=CascadeType.PERSIST)
@JoinColumn(name="customer_fk")
private Customer customer;

public Account(int accountId, String accoutType, LocalDate openingDate, double openingBalance, String desc) {
	super();
	this.accountId = accountId;
	this.accoutType = accoutType;
	this.openingDate = openingDate;
	this.openingBalance = openingBalance;
	this.desc = desc;
}


public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public String getAccoutType() {
	return accoutType;
}
public void setAccoutType(String accoutType) {
	this.accoutType = accoutType;
}
public LocalDate getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(LocalDate openingDate) {
	this.openingDate = openingDate;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
@Override
public String toString() {
	return "Account [accountId=" + accountId + ", accoutType=" + accoutType + ", openingDate=" + openingDate
			+ ", openingBalance=" + openingBalance + ", desc=" + desc + "]";
}

}