package com.cap.jpa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.jpa.dao.IAccountDBDao;
import com.cap.jpa.model.Account;

@Service("accountDbService")
public class AccountDBServiceImp implements IAccountDBService
{
	private IAccountDBDao accountDbDao;
	
	@Override
	public List<Account> getAllAccounts()
	{
		return accountDbDao.findAll();
	}
	
	@Override
	public List<Account> saveAccount(Account account)
	{
		accountDbDao.save(account);
		return getAllAccounts();
	}
	public List<Account> updateAccount(Account account)
	{
		
		return saveAccount(account);
	}
}
