package com.cap.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.jpa.model.Account;
import com.cap.jpa.service.IAccountDBService;

@RestController
@RequestMapping("/api/v1")
public class AccountRestController
{
@Autowired
private IAccountDBService accountDbService;

@GetMapping("/accounts")
public ResponseEntity<List<Account>> getAllAccounts()
{
	List<Account> accounts=accountDbService.getAllAccounts();
	if(accounts==null || accounts.isEmpty())
	
	return new ResponseEntity("sorry no account available",HttpStatus.NOT_FOUND);
	
	return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}


@PostMapping("/accounts")
public ResponseEntity<List<Account>> saveAccount(@RequestBody Account account)
{
	List<Account> accounts=accountDbService.saveAccount(account);
	if(accounts==null || accounts.isEmpty())
	
	return new ResponseEntity("sorry no account available",HttpStatus.NOT_FOUND);
	
	return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}

@PutMapping("/accounts")
public ResponseEntity<List<Account>> updateAccount(@RequestBody Account account)
{
	List<Account> accounts=accountDbService.updateAccount(account);
	if(accounts==null || accounts.isEmpty())
	
	return new ResponseEntity("sorry no update available",HttpStatus.NOT_FOUND);
	
	return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}

@PatchMapping("/accounts")
public ResponseEntity<List<Account>> updateAcc(@RequestBody Account account) {
	List<Account> customers = accountDbService.updateAccount(account);

	if (customers == null || customers.isEmpty()) {
		return new ResponseEntity("Product updated Successfully", HttpStatus.NOT_FOUND);
	}
	return new ResponseEntity<List<Account>>(customers, HttpStatus.OK);
}
}

