package com.cap.jpa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cap.jpa.model.Account;

public interface IAccountDBService 
{
public List<Account> getAllAccounts();
public List<Account> saveAccount(Account account);
public List<Account> updateAccount(Account account);	
}

