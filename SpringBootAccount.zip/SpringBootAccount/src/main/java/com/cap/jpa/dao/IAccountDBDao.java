package com.cap.jpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.jpa.model.Account;
@Repository("accountDbDao")
@Transactional
public interface IAccountDBDao extends JpaRepository<Account, Integer> {

}
