package com.test.assignment;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.stream.Stream;
import java.util.*;

public class DataReconcilation {

	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MMM-yyyy", Locale.ENGLISH);

	public static void main(String[] args) throws IOException {
	List<Reconcile> lstX = readFile("X.txt");
	List<Reconcile> lstY = readFile("Y.txt");

	String exactStr = "";
	String weekStr = "";
	String breakXStr = "";
	String breakYStr = "";

	Map<String, String> result = new HashMap<>();

	for (int i = 0; i < lstX.size(); i++) {
	Reconcile xs = lstX.get(i);
	Reconcile ys = lstY.get(i);
	if (xs.equals(ys)) {
	exactStr += xs.getTransactionID() + "" + ys.getTransactionID() + " ";
	result.put("EXACT", exactStr);
	} else if (xs.getAccountID().equals(ys.getAccountID())
	&& (xs.getAmount().equals(ys.getAmount()) 
					 || xs.getAmount().equals(ys.getAmount() - 0.01) 
			)
	&& (xs.getPostingDate().equals(ys.getPostingDate())
	|| dateCompareWeak(xs.getPostingDate(), ys.getPostingDate()))) {
	weekStr += xs.getTransactionID() + "" + ys.getTransactionID() + " ";
	result.put("WEAK", weekStr);
	} else {
	breakXStr += xs.getTransactionID()+" ";
	breakYStr += ys.getTransactionID()+" ";
	result.put("BREAKX", breakXStr);
	result.put("BREAKY", breakYStr);
	}

	}

	//result.forEach((k, v) -> System.out.println(k + "==" + v));
	System.out.println("#XY exact matches \n"+result.get("EXACT"));
	System.out.println("#XY weak matches \n"+result.get("WEAK"));
	System.out.println("#X breaks \n"+result.get("BREAKX"));

	System.out.println("#Y breaks \n"+result.get("BREAKY"));

	//System.out.println("#XY exact matches \n"+result.get("EXACT"));
		/*
		 * for(Entry key:result.entrySet()) {
		 * 
		 * if(key.equals("BREAKS")) { System.out.println(key.getValue()); } else {
		 * System.out.println(key.getKey()+" =="+key.getValue()); }
		 * 
		 * }
		 */

	}
	
	

	public static boolean dateCompareWeak(LocalDate d1, LocalDate d2) {		

	if ((d1.getDayOfWeek().equals(DayOfWeek.FRIDAY)) && (d2.getDayOfWeek().equals(DayOfWeek.SATURDAY)
	|| d2.getDayOfWeek().equals(DayOfWeek.SUNDAY) || d2.getDayOfWeek().equals(DayOfWeek.MONDAY)

	)) {
	return true;
	}

	if (d1.equals(d2.plusDays(-1))) {
	return true;
	}

	return false;
	}
	
	public static List<Reconcile> readFile(String fileName) throws IOException {

		List<Reconcile> ls = new ArrayList<Reconcile>();
		try (Stream<String> stream = Files.lines(Paths.get(fileName), StandardCharsets.UTF_8)) {
		stream.forEach(s -> {
		String[] ar = s.split(";");
		LocalDate dateTime = LocalDate.parse(ar[2].trim(), formatter);
		Reconcile r = new Reconcile(ar[0], ar[1], dateTime, Double.valueOf(ar[3]));
		// System.out.println(r);
		ls.add(r);
		});
		} catch (IOException e) {
		e.printStackTrace();
		}

		return ls;
		}
	
}
