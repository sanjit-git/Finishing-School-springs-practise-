package com.test.assignment;

import java.time.LocalDate;

public class Reconcile {

	
	private String transactionID;
	private String accountID;
	private LocalDate postingDate;
	private Double amount;

	public Reconcile(String transactionID, String accountID, LocalDate dateTime, Double amount) {
	this.transactionID = transactionID;
	this.accountID = accountID;
	this.postingDate = dateTime;
	this.amount = amount;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public LocalDate getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(LocalDate postingDate) {
		this.postingDate = postingDate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	
	
	@Override
	public String toString() {
	return "Reconcile [transactionID=" + transactionID + ", accountID=" + accountID + ", postingDate=" + postingDate
	+ ", amount=" + amount + "]";
	}

	@Override
	public boolean equals(Object obj) {

	Reconcile c = (Reconcile) obj;
	if (this.getAccountID().equals(c.getAccountID()) && this.getAmount().equals(c.getAmount())
	&& this.getPostingDate().equals(c.getPostingDate())) {
	return true;
	}
	return false;
	}
	
	
}
