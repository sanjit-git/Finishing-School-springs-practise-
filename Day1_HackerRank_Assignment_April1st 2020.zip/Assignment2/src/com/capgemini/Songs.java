package com.capgemini;


public class Songs {
	String songName;

	public Songs(String songName) {

		this.songName = songName;
	}

	public String getName() {
		return songName;
	}

	public void setName(String name) {
		this.songName = name;
	}

	@Override
	public String toString() {
		return "Songs [songName=" + songName + "]";
	}

}

