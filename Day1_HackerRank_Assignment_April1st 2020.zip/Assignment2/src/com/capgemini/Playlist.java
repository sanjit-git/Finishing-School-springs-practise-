package com.capgemini;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class Playlist {

	
	public static void main(String[] args) {
		List<Songs> library = new ArrayList<Songs>(); 
			library.add(new Songs("Basket Case"));
			library.add(new Songs("Blood On The Leaves"));
			library.add(new Songs("dancing in the dark"));
			library.add(new Songs("Cut Your Hair"));
			library.add(new Songs("Juicy"));
			
			  System.out.println("Available list:"+library.size()+"\npress");
		      System.out.println("0 - Basket Case\n" +
		                "1 - Blood On The Leaves\n" +
		                "2 - dancing in the dark\n" +
		                "3 - Cut Your Hair\n" +
		                "4 - Juicy\n" );
		      play(library);
		               	
	}

	private static void play(List<Songs> library) {
		System.out.println("Available action:\npress");
	      System.out.println("0 - to quit\n" +
	    		  "1 - to play next song\n" +
	    		  "2 - to play previous song\n");
	      
	      Scanner scanner = new Scanner(System.in);
	        boolean forward = true;
	        boolean isQuit = false;
	        ListIterator<Songs> listIterator = library.listIterator();
//	      ListIterator<Song> listIterator = playList.listIterator();


	          if (library.size() == 0) {
	              System.out.println("NO SONG IN PLAYLIST");
	              return;
	          } else {
	              System.out.println("NOW PLAYING " + listIterator.next().toString());
	             	          }
	          while (!isQuit) {
	              int choose = scanner.nextInt();
	              scanner.nextLine();

	              switch (choose) {
	                  case 0:
	                      System.out.println("Playlist is Done");
	                      isQuit = true;
	                      break;

	                  case 1: // PLAY NEXT SONG
	                      if (!forward) {
	                          if (listIterator.hasNext()) {
	                              listIterator.next(); 
	                          }
	                          forward = true; 
	                      }
	                      if (listIterator.hasNext()) {  
	                          System.out.println("Now playing " + listIterator.next().toString()); 
	                      } else {
	                          System.out.println("We have reached the end of the playlist");
	                          forward = false;
	                      }
	                      break;

	                  case 2:  // PLAY PREVIOUS SONG
	                      if (forward) {
	                          if (listIterator.hasPrevious()) {  
	                              listIterator.previous();
	                          }
	                          forward = false;
	                      }
	                      if (listIterator.hasPrevious()) { 
	                          System.out.println("Now playing " + listIterator.previous().toString());
	                      } else {  
	                          System.out.println("We are at the start of the playlist");
	                          forward = true;
	                      }
	                      break;
	              }
		
	}

	
}
}
