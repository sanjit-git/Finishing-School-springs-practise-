package com.cap.restful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
