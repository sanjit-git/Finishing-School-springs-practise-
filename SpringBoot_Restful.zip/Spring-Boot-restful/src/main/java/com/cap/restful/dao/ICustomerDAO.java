package com.cap.restful.dao;

import java.util.List;

import com.cap.restful.bean.Customer;

public interface ICustomerDAO 
{
		public List<Customer> getAllCustomers();
		public List<Customer> addCustomer(Customer customer);
		public List<Customer> deleteCustomer(int customerId);
		public List<Customer> updateCustomer(Customer customer);
	}
