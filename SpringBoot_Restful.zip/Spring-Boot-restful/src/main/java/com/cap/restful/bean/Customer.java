package com.cap.restful.bean;

import java.util.List;

public class Customer 
{
private int customerId; 
private String customerName;
private String emailId;
private String contactNumber;
private List<Account> account;
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public List<Account> getAccount() {
	return account;
}
public void setAccount(List<Account> account) {
	this.account = account;
}
public Customer(int customerId, String customerName, String emailId, String string, List<Account> account) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.emailId = emailId;
	this.contactNumber = string;
	this.account = account;
}
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", emailId=" + emailId
			+ ", contactNumber=" + contactNumber + ", account=" + account + "]";
}


}
