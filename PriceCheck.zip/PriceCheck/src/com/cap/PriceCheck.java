package com.cap;
import java.util.HashMap;
import java.util.Map;

public class PriceCheck {

public void sellingPriceCheck(String[] products, double[] productPrice, String[] productSold, double[] soldPrice) {

int error = 0;
Map<String, Double> map = new HashMap<String, Double>();

for (int i = 0; i < products.length; i++) {
map.put(products[i], productPrice[i]);
}
for (int i = 0; i < productSold.length; i++) {

if (map.containsKey(productSold[i]) && soldPrice[i] != map.get(productSold[i])) {
error++;
}

}

System.out.println("Number of errors => " + error);
}

public static void main(String[] args) {

String[] products = { "egg", "milk", "cheese" };
double d = 2.56;
double[] productPrice = { 2.89, 3.29, 5.79 };

String[] productSold = { "egg", "egg", "cheese", "milk" };
double[] soldPrice = { 2.89, 2.99, 5.97, 3.29 };

PriceCheck price = new PriceCheck();
price.sellingPriceCheck(products, productPrice, productSold, soldPrice);
}

}

