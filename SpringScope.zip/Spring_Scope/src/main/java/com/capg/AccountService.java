package com.capg;

public class AccountService {

	   private String accountHolder;

	   public String getAccountHolder() {
	      return accountHolder;
	   }

	   public void setAccountHolder(String accountHolder) {
	      this.accountHolder = accountHolder;
	   }

	}