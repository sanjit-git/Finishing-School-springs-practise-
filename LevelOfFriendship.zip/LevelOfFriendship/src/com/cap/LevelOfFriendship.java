package com.cap;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class Acquaintance {

String name;

public Acquaintance() {
}

public Acquaintance(String name) {
this.name = name;

}

public void getStatus() {
System.out.println(name + " is just acquaintance");
}
}

class Friend extends Acquaintance {

String homeTown;

public Friend() {
}

public Friend(String name, String homeTown) {
this.name = name;
this.homeTown = homeTown;
}

@Override
public void getStatus() {
System.out.println(name + " is a friend and he is from " + homeTown);
}
}

class BestFriend extends Friend {

String favSong;

public BestFriend() {
}

public BestFriend(String name, String homeTown, String favSong) {
this.name = name;
this.homeTown = homeTown;
this.favSong = favSong;
}

@Override
public void getStatus() {
System.out.println(name + " is my best friend. He is from " + homeTown + " and his favSong is " + favSong);
}
}

public class LevelOfFriendship {

public static void levelFriend(List<List<String>> list) {

list.forEach(lis -> {
Acquaintance a = null;
if (lis.size() == 1) {
a = new Acquaintance(lis.get(0));
} else if (lis.size() == 2) {
a = new Friend(lis.get(0), lis.get(1));
} else if (lis.size() == 3) {
a = new BestFriend(lis.get(0), lis.get(1), lis.get(2));
}

if (Objects.nonNull(a)) {
a.getStatus();
}
});

}

public static void main(String[] args) throws IOException {

System.out.println("Enter number of input : ");
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
int n = Integer.parseInt(br.readLine());

List<List<String>> list = new ArrayList<List<String>>();
System.out.println("Enter  level of friendship ");
while (n > 0) {
String s = br.readLine(); // Input the number seperated by space
List<String> input = new ArrayList();
String[] split = s.split(" ");
for (int i = 1; i < split.length; i++) {
input.add(split[i]);
}
list.add(input);
n--;
}

levelFriend(list);
}

}
