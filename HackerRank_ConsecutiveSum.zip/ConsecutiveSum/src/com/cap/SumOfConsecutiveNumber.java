package com.cap;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

class Solution
{
	static int countConsecutive(long num) 
    { 
        // constraint on values of L gives us the  
        // time Complexity as O(N^0.5) 
        int count = 0; 
        for (int i = 1; i * (i + 1) < 2 * num; i++) 
        { 
            float a = (float) ((1.0 * num-(i * (i + 1)) / 2) / (i + 1)); 
            //System.out.println(a);
            if (a-(int)a == 0.0)  
                count++; 
        } 
        return count; 
    } 
}
public class SumOfConsecutiveNumber
{
	public static void main(String args[])throws IOException
	{
		BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the number=");
		long num=Long.parseLong(bufferedReader.readLine().trim());
		//BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));
		
		System.out.println(Solution.countConsecutive(num));
		
		
		
	}
}

