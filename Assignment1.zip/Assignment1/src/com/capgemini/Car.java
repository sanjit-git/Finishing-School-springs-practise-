package com.capgemini;

import java.io.*;
import java.util.Scanner;

abstract class Car
 {
protected boolean isSedan;
protected String seats;

public Car(boolean isSedan, String seats) {
	super();
	this.isSedan = isSedan;
	this.seats = seats;
}

public boolean getIsSedan() {
	return this.isSedan;
}

public String getSeats() {
	return this.seats;
}
abstract public String getMileage();
public void printCar(String name)
{
	System.out.println("A "+name+" is "+ (this.getIsSedan() ?"":"not ")
			+"Sedan, is "+this.getSeats()+ "seater,and has a millage of "+this.getMileage()+".");
}
 }

class Wagonr extends Car{
	
	int mileage ;
	
	public Wagonr(int mileage) {
		super(false, "4");
		this.mileage=mileage;
	}

	public String getMileage() {
		return mileage+" kmpl";
	}

}

class Hondacity extends Car{
	
	int mileage ;
	
	public Hondacity(int mileage) {
		super(true, "4");
		this.mileage=mileage;
	}
	public String getMileage() {
		return mileage+" kmpl";
	}
}
class InnovaCrysta extends Car
{
	int mileage ;
	public InnovaCrysta(int mileage) {
		super(true, "6");
		this.mileage=mileage;
	}
	public String getMileage() {
		return mileage+" kmpl";
	}
}

class Solution
{
	public static void main(String args[])throws IOException
	{
		BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(System.in));
		int carType=Integer.parseInt(bufferedReader.readLine().trim());
		int carMileage=Integer.parseInt(bufferedReader.readLine().trim());
		
		if(carType==0)
		{
			Car wagonR=new Wagonr(carMileage);
			wagonR.printCar("wagonR");
		}
		
		if(carType==1)
		{
			Car hondacity=new Hondacity(carMileage);
			hondacity.printCar("Hondacity");
		}
		
		if(carType==2)
		{
			Car innovaCrysta=new InnovaCrysta(carMileage);
			innovaCrysta.printCar("InnovaCrysta");
		}
}
}
