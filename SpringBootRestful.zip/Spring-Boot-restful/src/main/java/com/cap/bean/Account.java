package com.cap.bean;

import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;
public class Account
{
	private int accountId;
	private String accountType;
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private LocalDate openingDate=LocalDate.now();
	private double OpeningBalance;
	private String desc;
	public Account(int accountId, String accountType, LocalDate openingDate, double openingBalance,String desc) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.openingDate = openingDate;
		OpeningBalance = openingBalance;
		this.desc = desc;
	}
	
	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public double getOpeningBalance() {
		return OpeningBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		OpeningBalance = openingBalance;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		desc = desc;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountType=" + accountType + ", openingDate=" + openingDate
				+ ", OpeningBalance=" + OpeningBalance + ", Desc=" + desc + "]";
	}
	
	
	

}
