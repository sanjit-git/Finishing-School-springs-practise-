package com.cap.dao;

import java.util.List;

import com.cap.bean.Customer;

public interface ICustomerDAO 
{
		public List<Customer> getAllCustomers();
		public List<Customer> addCustomer(Customer customer);
		public List<Customer> deleteCustomer(int customerId);
		public List<Customer> updateCustomer(Customer customer);
	}
